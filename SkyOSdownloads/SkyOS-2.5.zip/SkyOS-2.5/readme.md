no forking unless you want to contribute

# skyOS readme.md file
open-source operating system for the Scratch Computing Alliance [SCA]

## description
an os built FROM SCRATCH!! its open-source easy to contribute
to because it is written in python a very easy langauge! (to learn and program in)
*thanks god github exists so the team can work on this.*
how to contribute below!

## contributing
email:
terpstragraham@gmail.com
and wait for a notification that you can contribute.
then click accept head over to this repository
and help us work on skyOS!

## website
https://webbrowser11.github.io/skyOSweb/
also for more infromation on cotributing!

## work in progress!
work on this project is STILL IN PROGRESS

<ins>written from SCRATCH!<ins>
























































CLASSIFIED (kinda):
new SkyOS lua edition maybe????
new PAL package manager coming to SkyOS (maybe???)
