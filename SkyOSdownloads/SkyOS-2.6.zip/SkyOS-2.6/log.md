# The Log

## 6/22/24
Creation

v0.1-0.9 The pre-creation and bug fixing stage (6/22/24 11:00am-5:00pm)
v1.0 Initial release (6/22/24 8:00pm)

## 6/23/24
v1.1 Added new app! Simple text app (1:00-2:00)

## 6/24/24
v1.2
Quick bug fix (10:35)
Lots of bug fixes (3:00-5:00)

## 6/25/24
v1.3
Not much...

## 6/26/24
v1.4
Added a command with a new parameter.

## 6/27/24
v1.5 New app (11:30-12:00)
v1.6 Updated kernel (12:00-12:30)

## 6/28/24
v1.7
Updated the kernel (added time command did some bug fixes, 1:00 - 2:00)

## 6/30/24
v1.8
Added a new parameter for the command TREE created on the 26th.

## 7/2/24
v1.9 
Shutdown scripts

## 7/3/24
v2.0
Bug fix

## 7/4/24
v2.0
Did an update to the copyright notice.

## 7/16/24
v2.1
Updated things and changed many parts and added Mac support.

## 7/17/24
v2.2
Syntax error updates

## 7/18/24
v2.3
Added BIOS and the first version out of the last 2 ready to release.

## 7/19/24
v2.4 Bug fixes!

## 7/23/24
v2.4.1
Added Java support, InterApp Mocha for launching JARs, and a new "jars" folder for storing JARs (with an included hello-world.jar file).
Added a kernel panic function and a few bug fixes.

## 7/24/24
v2.4.2
Deleted Java support InterApp and jars and jar folder
Kept kernel panic BUGFIXESSS!!!!

## 7/31/24
v2.6
Updated BIOS script and bug fixes. (5:03-6:12)

## 8/1/24 - 8/12/24
v2.6
working on the next release

## Stay tuned
Stay tuned for more logs and update info!
